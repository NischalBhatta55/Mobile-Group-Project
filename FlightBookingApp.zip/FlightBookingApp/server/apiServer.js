const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB setup
const { MongoClient } = require('mongodb');
const uri = 'mongodb+srv://nischalbhatta:nischalbhatta@cluster0.tkhqrmw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
const client = new MongoClient(uri);

let userCollection;
let bookingCollection;

// Connect to MongoDB
async function connectDB() {
  try {
    await client.connect();
    const db = client.db('flightbooking');
    userCollection = db.collection('users');
    bookingCollection = db.collection('bookings');
    console.log('[✅] Connected to MongoDB Atlas');
  } catch (err) {
    console.error('[❌] MongoDB connection failed:', err);
  }
}
connectDB();

// Root check
app.get('/', (req, res) => {
  console.log('[INFO] Root route hit');
  res.send('<h3>Flight Booking Server is running</h3>');
});

// Register User
app.post('/registerUser', async (req, res) => {
  const user = req.body;
  console.log(`[POST] Registering user: ${user.email}`);
  try {
    const result = await userCollection.insertOne(user);
    console.log(`[✅] User registered: ${users.email}`);
    res.status(200).send(result);
  } catch (err) {
    console.error('[❌] Error registering user:', err);
    res.status(500).json({ message: 'Registration failed', error: err });
  }
});

// Verify User Login
app.post('/verifyUser', async (req, res) => {
  const { email, password } = req.body;
  console.log(`[POST] Login attempt for: ${email}`);
  try {
    const user = await userCollection.findOne({ email, password });
    if (user) {
      console.log(`[✅] Login successful: ${email}`);
      res.status(200).send([user]);
    } else {
      console.log(`[⚠️] Login failed: ${email}`);
      res.status(200).send([]);
    }
  } catch (err) {
    console.error('[❌] Login error:', err);
    res.status(500).json({ message: 'Login failed', error: err });
  }
});

// Check if email exists
app.get('/checkEmail', async (req, res) => {
  const email = req.query.email;
  console.log(`[GET] Checking if email exists: ${email}`);
  try {
    const existing = await userCollection.findOne({ email });
    res.status(200).send({ exists: !!existing });
  } catch (err) {
    console.error('[❌] Email check failed:', err);
    res.status(500).json({ message: 'Email check failed', error: err });
  }
});

// Post a flight booking
app.post('/postOrderData', async (req, res) => {
  const order = req.body;
  console.log(`[POST] New flight booking from ${order.customerEmail}`);
  try {
    const result = await orderCollection.insertOne(order);
    console.log(`[✅] Booking inserted. Booking No: ${order.bookingNo}`);
    res.status(200).send(result);
  } catch (err) {
    console.error('[❌] Booking insertion failed:', err);
    res.status(500).json({ message: 'Booking failed', error: err });
  }
});

// Get user's bookings
app.get('/getUserOrders', async (req, res) => {
  const email = req.query.email;
  console.log(`[GET] Fetching bookings for: ${email}`);
  try {
    const bookings = await orderCollection.find({ customerEmail: email }).toArray();
    console.log(`[✅] Found ${bookings.length} booking(s) for ${email}`);
    res.status(200).send(bookings);
  } catch (err) {
    console.error('[❌] Error fetching bookings:', err);
    res.status(500).json({ message: 'Fetch failed', error: err });
  }
});

// Delete all bookings for a user
app.delete('/deleteUserOrders', async (req, res) => {
  const { email } = req.body;
  console.log(`[DELETE] Deleting all bookings for: ${email}`);
  try {
    const result = await orderCollection.deleteMany({ customerEmail: email });
    console.log(`[✅] Deleted ${result.deletedCount} bookings for ${email}`);
    res.status(200).send({ count: result.deletedCount });
  } catch (err) {
    console.error('[❌] Deletion failed:', err);
    res.status(500).json({ message: 'Deletion failed', error: err });
  }
});

// Start server
app.listen(port, () => {
  console.log(`[🚀] Flight Booking Server running at http://localhost:${port}`);
});
