const domainUrl = "http://localhost:3000";

$(document).ready(function () {
  const debug = true;

  // ------------------ Login ------------------
  $("#loginButton").click(function (e) {
    e.preventDefault();
    let email = $("input[name='email']").val().trim().toLowerCase(); // Lowercase
    let password = $("input[name='password']").val();

    localStorage.removeItem("inputData");
    $("#loginForm").submit();

    if (localStorage.inputData != null) {
      const inputData = JSON.parse(localStorage.getItem("inputData"));

      $.post(domainUrl + "/verifyUser", inputData, function (data) {
        if (data.length > 0) {
          localStorage.setItem("userInfo", JSON.stringify(data[0]));
          $("body").pagecontainer("change", "#homePage");
        } else {
          alert("Login failed");
        }
        $("#loginForm").trigger("reset");
      });
    }
  });

  $("#loginForm").validate({
    submitHandler: function (form) {
      const formData = $(form).serializeArray();
      const inputData = {};
      formData.forEach((field) => (inputData[field.name] = field.value));
      localStorage.setItem("inputData", JSON.stringify(inputData));
    },
    rules: {
      email: { required: true, email: true },
      password: { required: true, minlength: 4 },
    },
  });

  // ------------------ Sign Up ------------------
  $("#signupButton").click(function (e) {
    e.preventDefault();
    let email = $("#signupEmail").val().trim().toLowerCase(); // Lowercase

    localStorage.removeItem("signupData");
    $("#signupForm").submit();

    if (localStorage.signupData != null) {
      const signupData = JSON.parse(localStorage.getItem("signupData"));
      $.get(
        domainUrl + "/checkEmail?email=" + signupData.email,
        function (data) {
          if (data.exists) {
            alert("Email already registered");
          } else {
            $.post(domainUrl + "/registerUser", signupData, function () {
              alert("Registration successful");
              localStorage.setItem("userInfo", JSON.stringify(signupData));
              $("body").pagecontainer("change", "#homePage");
              $("#signupForm").trigger("reset");
            });
          }
        }
      );
    }
  });

  $("#signupForm").validate({
    submitHandler: function (form) {
      const formData = $(form).serializeArray();
      const inputData = {};
      formData.forEach((field) => (inputData[field.name] = field.value));
      localStorage.setItem("signupData", JSON.stringify(inputData));
    },
  });

  // ------------------ Confirm Booking ------------------
  $("#confirmBookingButton").click(function () {
    localStorage.removeItem("inputData");
    $("#bookingForm").submit();

    if (localStorage.inputData != null) {
      const bookingInfo = JSON.parse(localStorage.getItem("inputData"));
      const userInfo = JSON.parse(localStorage.getItem("userInfo"));

      bookingInfo.customerEmail = userInfo.email;
      bookingInfo.bookingNo = Math.floor(Math.random() * 900000 + 100000);

      localStorage.setItem("bookingInfo", JSON.stringify(bookingInfo));

      $.post(domainUrl + "/postBookingData", bookingInfo, function () {
        $("#bookingForm").trigger("reset");
        $("body").pagecontainer("change", "#bookingConfirmationPage");
      });
    }
  });

  $("#bookingForm").validate({
    submitHandler: function (form) {
      const formData = $(form).serializeArray();
      const inputData = {};
      formData.forEach((field) => (inputData[field.name] = field.value));
      localStorage.setItem("inputData", JSON.stringify(inputData));
    },
  });

  // ------------------ Search Booking ------------------
  $("#searchBookingBtn").click(function () {
    const bookingNo = $("#searchBookingNo").val().trim();

    if (!bookingNo) {
      alert("Please enter a booking number.");
      return;
    }

    $.get(domainUrl + "/searchBooking?bookingNo=" + bookingNo, function (data) {
      if (data && data.bookingNo) {
        $("#searchResultContainer").html(`
                    <div style="margin-bottom:15px; border-bottom:1px solid #ccc; padding-bottom:10px;">
                        <p><b>Booking No:</b> ${data.bookingNo}</p>
                        <p><b>Airline:</b> ${data.airline}</p>
                        <p><b>From:</b> ${data.fromAirport}</p>
                        <p><b>To:</b> ${data.toAirport}</p>
                        <p><b>Departure:</b> ${data.departureDate}</p>
                        <p><b>Arrival:</b> ${data.arrivalDate}</p>
                    </div>
                `);
      } else {
        $("#searchResultContainer").html(
          `<p style="color:red;">No booking found with this number.</p>`
        );
      }
    }).fail(function () {
      $("#searchResultContainer").html(
        `<p style="color:red;">Error connecting to server.</p>`
      );
    });
  });

  // ------------------ Show Booking Confirmation ------------------
  $(document).on("pagebeforeshow", "#bookingConfirmationPage", function () {
    const booking = JSON.parse(localStorage.getItem("bookingInfo"));
    if (!booking) return;

    $("#orderInfo").html(`
            <table><tbody>
                <tr><td><b>Booking No:</b></td><td>${booking.bookingNo}</td></tr>
                <tr><td><b>Email:</b></td><td>${booking.customerEmail}</td></tr>
                <tr><td><b>Airline:</b></td><td>${booking.airline}</td></tr>
                <tr><td><b>From:</b></td><td>${booking.fromAirport}</td></tr>
                <tr><td><b>To:</b></td><td>${booking.toAirport}</td></tr>
                <tr><td><b>Departure:</b></td><td>${booking.departureDate}</td></tr>
                <tr><td><b>Arrival:</b></td><td>${booking.arrivalDate}</td></tr>
                <tr><td><b>Name:</b></td><td>${booking.firstName} ${booking.lastName}</td></tr>
                <tr><td><b>Phone:</b></td><td>${booking.phoneNumber}</td></tr>
                <tr><td><b>Address:</b></td><td>${booking.address}, ${booking.postcode}</td></tr>
            </tbody></table>
        `);

    // Fill the boarding pass fields
    $("#bpAirline").text(booking.airline || "");
    $("#bpReference").text(booking.bookingNo || "");
    $("#bpPassenger").text(
      (booking.firstName || "") + " " + (booking.lastName || "")
    );
    $("#bpFlightNo").text(
      booking.airline
        ? booking.airline.substring(0, 2).toUpperCase() +
            (booking.bookingNo ? booking.bookingNo.toString().slice(-3) : "123")
        : ""
    );
    $("#bpFrom").text(
      $("#fromAirport option[value='" + booking.fromAirport + "']").text() ||
        booking.fromAirport ||
        ""
    );
    $("#bpTo").text(
      $("#toAirport option[value='" + booking.toAirport + "']").text() ||
        booking.toAirport ||
        ""
    );
    $("#bpDate").text(booking.departureDate || "");
    $("#bpTime").text("09:30"); // You can add a time field if you want
  });

  // ------------------ Load Past Bookings ------------------
  $(document).on("pagebeforeshow", "#flightHistoryPage", function () {
    const email = JSON.parse(localStorage.getItem("userInfo")).email;
    $("#pastBookingsList").html("");

    $.get(domainUrl + "/getUserBookings?email=" + email, function (data) {
      if (data.length > 0) {
        data.forEach((booking) => {
          $("#pastBookingsList").append(`
                        <div class="history-booking-card">
                            <div class="history-booking-header">
                                <div class="history-booking-title">${booking.airline}</div>
                                <div class="history-booking-ref">#${booking.bookingNo}</div>
                            </div>
                            <div class="history-booking-details">
                                <div><span>From:</span> ${booking.fromAirport}</div>
                                <div><span>To:</span> ${booking.toAirport}</div>
                                <div><span>Departure:</span> ${booking.departureDate}</div>
                                <div><span>Arrival:</span> ${booking.arrivalDate}</div>
                            </div>
                            <div class="history-booking-actions">
                                <button class="history-delete-btn deleteBtn" data-id="${booking.bookingNo}">Delete</button>
                            </div>
                        </div>
                    `);
        });
      } else {
        $("#pastBookingsList").append("<p>No bookings found.</p>");
      }
    });
  });

  // ------------------ Delete All Bookings ------------------
  $("#deleteBookingsBtn").click(function () {
    // Instead of deleting all, redirect to Past Bookings page to delete individually
    $("body").pagecontainer("change", "#flightHistoryPage");
  });

  // ------------------ Delete Single Booking ------------------
  $(document).on("click", ".deleteBtn", function () {
    const bookingNo = $(this).data("id");

    if (confirm(`Are you sure you want to delete booking #${bookingNo}?`)) {
      $.ajax({
        url: domainUrl + "/deleteBooking",
        type: "DELETE",
        contentType: "application/json",
        data: JSON.stringify({ bookingNo }),
        success: function (res) {
          alert(res.message);
          $("body").pagecontainer("change", "#homePage");
          setTimeout(() => {
            $("body").pagecontainer("change", "#flightHistoryPage");
          }, 300);
        },
        error: function (xhr) {
          alert("Error deleting booking: " + xhr.responseJSON.message);
        },
      });
    }
  });
});
