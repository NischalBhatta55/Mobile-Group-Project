// index.js for Flight Booking App

const domainUrl = "http://localhost:3000";

$(document).ready(function () {
    let debug = true;

    // ------------------ Login ------------------
    $('#loginButton').click(function () {
        localStorage.removeItem("inputData");
        $("#loginForm").submit();

        if (localStorage.inputData != null) {
            const inputData = JSON.parse(localStorage.getItem("inputData"));

            $.post(domainUrl + "/verifyUser", inputData, function (data, status) {
                if (data.length > 0) {
                    localStorage.setItem("userInfo", JSON.stringify(data[0]));
                    $("body").pagecontainer("change", "#homePage");
                } else {
                    alert("Login failed");
                }
                $("#loginForm").trigger('reset');
            });
        }
    });

    $("#loginForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("inputData", JSON.stringify(inputData));
        },
        rules: {
            email: { required: true, email: true },
            password: { required: true, minlength: 4 }
        }
    });

    // ------------------ Sign Up ------------------
    $('#signupButton').click(function () {
        localStorage.removeItem("signupData");
        $("#signupForm").submit();

        if (localStorage.signupData != null) {
            const signupData = JSON.parse(localStorage.getItem("signupData"));
            $.get(domainUrl + "/checkEmail?email=" + signupData.email, function (data) {
                if (data.exists) {
                    alert("Email already registered");
                } else {
                    $.post(domainUrl + "/registerUser", signupData, function (res, status) {
                        alert("Registration successful");
                        localStorage.setItem("userInfo", JSON.stringify(signupData));
                        $("body").pagecontainer("change", "#homePage");
                        $("#signupForm").trigger('reset');
                    });
                }
            });
        }
    });

    $("#signupForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("signupData", JSON.stringify(inputData));
        },
        rules: {
            email: { required: true, email: true },
            password: { required: true, minlength: 4 },
            firstName: { required: true },
            lastName: { required: true },
            phoneNumber: { required: true },
            address: { required: true },
            postcode: { required: true },
            state: { required: true }
        }
    });

    // ------------------ Flight Selection ------------------
    $('#flightList li').click(function () {
        const name = $(this).find('#flightName').text();
        const price = $(this).find('#flightPrice').text();
        const image = $(this).find('#flightImage').attr('src');

        localStorage.setItem("flightName", name);
        localStorage.setItem("flightPrice", price);
        localStorage.setItem("flightImage", image);

        $('#selectedFlightName').text(name);
        $('#selectedFlightPrice').text(price);
        $('#selectedFlightImage').attr('src', image);
    });

    // ------------------ Confirm Booking ------------------
    $('#confirmBookingButton').click(function () {
        localStorage.removeItem("inputData");
        $("#bookingForm").submit();

        if (localStorage.inputData != null) {
            const bookingInfo = JSON.parse(localStorage.getItem("inputData"));

            bookingInfo.flightName = localStorage.getItem("flightName");
            bookingInfo.flightPrice = localStorage.getItem("flightPrice");
            bookingInfo.flightImage = localStorage.getItem("flightImage");
            bookingInfo.customerEmail = JSON.parse(localStorage.getItem("userInfo")).email;
            bookingInfo.bookingNo = Math.floor(Math.random() * 1000000);

            localStorage.setItem("bookingInfo", JSON.stringify(bookingInfo));

            $.post(domainUrl + "/postOrderData", bookingInfo, function (res, status) {
                $("#bookingForm").trigger('reset');
                $("body").pagecontainer("change", "#bookingConfirmationPage");
            });
        }
    });

    $("#bookingForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("inputData", JSON.stringify(inputData));
        },
        rules: {
            firstName: { required: true },
            lastName: { required: true },
            phoneNumber: { required: true },
            address: { required: true },
            postcode: { required: true },
            travelDate: { required: true }
        }
    });

    // ------------------ Show Booking Info ------------------
    $(document).on("pagebeforeshow", "#bookingConfirmationPage", function () {
        const info = JSON.parse(localStorage.getItem("bookingInfo"));
        if (!info) return;

        $('#bookingInfo').html(`
            <table><tbody>
                <tr><td>Booking No:</td><td>${info.bookingNo}</td></tr>
                <tr><td>Email:</td><td>${info.customerEmail}</td></tr>
                <tr><td>Flight:</td><td>${info.flightName}</td></tr>
                <tr><td>Price:</td><td>${info.flightPrice}</td></tr>
                <tr><td>Name:</td><td>${info.firstName} ${info.lastName}</td></tr>
                <tr><td>Phone:</td><td>${info.phoneNumber}</td></tr>
                <tr><td>Address:</td><td>${info.address}, ${info.postcode}</td></tr>
                <tr><td>Travel Date:</td><td>${info.travelDate}</td></tr>
            </tbody></table>
        `);
    });

    // ------------------ Past Bookings ------------------
    $(document).on("pagebeforeshow", "#flightHistoryPage", function () {
        const email = JSON.parse(localStorage.getItem("userInfo")).email;
        $('#pastBookings').html("");
        $.get(domainUrl + "/getUserOrders?email=" + email, function (data) {
            if (data.length > 0) {
                data.forEach(booking => {
                    $('#pastBookings').append(`<p><strong>${booking.flightName}</strong> on ${booking.travelDate}</p>`);
                });
            } else {
                $('#pastBookings').append('<p>No past bookings found.</p>');
            }
        });
    });

    // ------------------ Delete All Bookings ------------------
    $('#deleteBookingsBtn').click(function () {
        const email = JSON.parse(localStorage.getItem("userInfo")).email;
        if (confirm("Delete all bookings?")) {
            $.ajax({
                url: domainUrl + "/deleteUserOrders",
                type: "DELETE",
                contentType: "application/json",
                data: JSON.stringify({ email }),
                success: function (res) {
                    $('#deleteConfirmationMessage').html(`<h3>${res.count} bookings deleted</h3>`);
                    $("body").pagecontainer("change", "#deleteConfirmationPage");
                }
            });
        }
    });
});
