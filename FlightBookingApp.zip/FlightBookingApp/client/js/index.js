const domainUrl = "http://localhost:3000";

$(document).ready(function () {
    const debug = true;

    // ------------------ Login ------------------
    $('#loginButton').click(function () {
        localStorage.removeItem("inputData");
        $("#loginForm").submit();

        if (localStorage.inputData != null) {
            const inputData = JSON.parse(localStorage.getItem("inputData"));

            $.post(domainUrl + "/verifyUser", inputData, function (data) {
                if (data.length > 0) {
                    localStorage.setItem("userInfo", JSON.stringify(data[0]));
                    $("body").pagecontainer("change", "#homePage");
                } else {
                    alert("Login failed");
                }
                $("#loginForm").trigger('reset');
            });
        }
    });

    $("#loginForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("inputData", JSON.stringify(inputData));
        },
        rules: {
            email: { required: true, email: true },
            password: { required: true, minlength: 4 }
        }
    });

    // ------------------ Sign Up ------------------
    $('#signupButton').click(function () {
        localStorage.removeItem("signupData");
        $("#signupForm").submit();

        if (localStorage.signupData != null) {
            const signupData = JSON.parse(localStorage.getItem("signupData"));
            $.get(domainUrl + "/checkEmail?email=" + signupData.email, function (data) {
                if (data.exists) {
                    alert("Email already registered");
                } else {
                    $.post(domainUrl + "/registerUser", signupData, function () {
                        alert("Registration successful");
                        localStorage.setItem("userInfo", JSON.stringify(signupData));
                        $("body").pagecontainer("change", "#homePage");
                        $("#signupForm").trigger('reset');
                    });
                }
            });
        }
    });

    $("#signupForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("signupData", JSON.stringify(inputData));
        }
    });

    // ------------------ Confirm Booking ------------------
    $('#confirmBookingButton').click(function () {
        localStorage.removeItem("inputData");
        $("#bookingForm").submit();

        if (localStorage.inputData != null) {
            const bookingInfo = JSON.parse(localStorage.getItem("inputData"));
            const userInfo = JSON.parse(localStorage.getItem("userInfo"));

            bookingInfo.customerEmail = userInfo.email;
            bookingInfo.bookingNo = Math.floor(Math.random() * 900000 + 100000);

            localStorage.setItem("bookingInfo", JSON.stringify(bookingInfo));

            $.post(domainUrl + "/postBookingData", bookingInfo, function () {
                $("#bookingForm").trigger('reset');
                $("body").pagecontainer("change", "#bookingConfirmationPage");
            });
        }
    });

    $("#bookingForm").validate({
        submitHandler: function (form) {
            const formData = $(form).serializeArray();
            const inputData = {};
            formData.forEach(field => inputData[field.name] = field.value);
            localStorage.setItem("inputData", JSON.stringify(inputData));
        }
    });

    // ------------------ Show Booking Confirmation ------------------
    $(document).on("pagebeforeshow", "#bookingConfirmationPage", function () {
        const booking = JSON.parse(localStorage.getItem("bookingInfo"));
        if (!booking) return;

        $('#orderInfo').html(`
            <table><tbody>
                <tr><td><b>Booking No:</b></td><td>${booking.bookingNo}</td></tr>
                <tr><td><b>Email:</b></td><td>${booking.customerEmail}</td></tr>
                <tr><td><b>Airline:</b></td><td>${booking.airline}</td></tr>
                <tr><td><b>From:</b></td><td>${booking.fromAirport}</td></tr>
                <tr><td><b>To:</b></td><td>${booking.toAirport}</td></tr>
                <tr><td><b>Departure:</b></td><td>${booking.departureDate}</td></tr>
                <tr><td><b>Arrival:</b></td><td>${booking.arrivalDate}</td></tr>
                <tr><td><b>Name:</b></td><td>${booking.firstName} ${booking.lastName}</td></tr>
                <tr><td><b>Phone:</b></td><td>${booking.phoneNumber}</td></tr>
                <tr><td><b>Address:</b></td><td>${booking.address}, ${booking.postcode}</td></tr>
            </tbody></table>
        `);
    });

    // ------------------ Load Past Bookings ------------------
    $(document).on("pagebeforeshow", "#flightHistoryPage", function () {
        const email = JSON.parse(localStorage.getItem("userInfo")).email;
        $('#pastBookingsList').html("");

        $.get(domainUrl + "/getUserBookings?email=" + email, function (data) {
            if (data.length > 0) {
                data.forEach(booking => {
                    $('#pastBookingsList').append(`
                        <div style="margin-bottom:15px; border-bottom:1px solid #ccc; padding-bottom:10px;">
                            <p><b>Booking No:</b> ${booking.bookingNo}</p>
                            <p><b>Airline:</b> ${booking.airline}</p>
                            <p><b>From:</b> ${booking.fromAirport}</p>
                            <p><b>To:</b> ${booking.toAirport}</p>
                            <p><b>Departure:</b> ${booking.departureDate}</p>
                            <p><b>Arrival:</b> ${booking.arrivalDate}</p>
                        </div>
                    `);
                });
            } else {
                $('#pastBookingsList').append('<p>No bookings found.</p>');
            }
        });
    });

    // ------------------ Delete All Bookings ------------------
    $('#deleteBookingsBtn').click(function () {
        const email = JSON.parse(localStorage.getItem("userInfo")).email;
        if (confirm("Are you sure you want to delete all bookings?")) {
            $.ajax({
                url: domainUrl + "/deleteUserBookings",
                type: "DELETE",
                contentType: "application/json",
                data: JSON.stringify({ email }),
                success: function (res) {
                    $('#deleteConfirmationMessage').html(`<h3>${res.count} booking(s) deleted</h3>`);
                    $("body").pagecontainer("change", "#deleteConfirmationPage");
                }
            });
        }
    });
});
